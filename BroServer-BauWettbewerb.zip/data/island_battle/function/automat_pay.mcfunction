# Vorhandene Scheine im Automaten mitzaehlen und zusammenlegen
scoreboard players set #old kunde_t 0
execute if data block ~ ~ ~ Items[{id:"minecraft:prismarine_shard"}] store result score #old kunde_t run data get block ~ ~ ~ Items[{id:"minecraft:prismarine_shard"}].count
data remove block ~ ~ ~ Items[{id:"minecraft:prismarine_shard"}]
scoreboard players operation #earn kunde_t += #old kunde_t
# Bis 64 in den Automaten legen, Rest oben drauf werfen
scoreboard players operation #n kunde_t = #earn kunde_t
execute if score #n kunde_t matches 65.. run scoreboard players set #n kunde_t 64
execute store result storage island_battle:am pay.n int 1 run scoreboard players get #n kunde_t
function island_battle:automat_put with storage island_battle:am pay
scoreboard players operation #earn kunde_t -= #n kunde_t
execute if score #earn kunde_t matches 1.. run function island_battle:automat_overflow
