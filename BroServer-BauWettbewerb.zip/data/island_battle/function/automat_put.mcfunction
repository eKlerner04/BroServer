$data modify block ~ ~ ~ Items append value {Slot:26b,id:"minecraft:prismarine_shard",count:$(n),components:{"minecraft:custom_name":"Bro-Dollar","minecraft:item_model":"island_battle:bro_dollar"}}
