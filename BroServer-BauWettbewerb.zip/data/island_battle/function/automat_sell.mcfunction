# Inventar auslesen und Warenwert berechnen (in Zehntel-Dollars)
data modify storage island_battle:am inv set from block ~ ~ ~ Items
scoreboard players set #earn kunde_t 0
function island_battle:automat_loop
execute if score #earn kunde_t matches ..9 run return 0
# Verkaufte Warentypen aus dem Automaten entfernen
data remove block ~ ~ ~ Items[{id:"minecraft:wheat"}]
data remove block ~ ~ ~ Items[{id:"minecraft:green_dye"}]
data remove block ~ ~ ~ Items[{id:"minecraft:dried_kelp"}]
data remove block ~ ~ ~ Items[{id:"minecraft:beetroot"}]
data remove block ~ ~ ~ Items[{id:"minecraft:brick"}]
data remove block ~ ~ ~ Items[{id:"minecraft:bone"}]
# Zehntel -> ganze Dollars
scoreboard players operation #earn kunde_t /= #ten kunde_t
scoreboard players operation #show kunde_t = #earn kunde_t
function island_battle:automat_pay
tellraw @a[distance=..32] [{"text":"[AUTOMAT] ","color":"green","bold":true},{"text":"Kundschaft hat eingekauft: +","color":"green"},{"score":{"name":"#show","objective":"kunde_t"},"color":"gold"},{"text":" Bro-Dollars liegen IM Automaten!","color":"green"}]
playsound minecraft:entity.experience_orb.pickup master @a[distance=..24] ~ ~ ~ 1 0.8
particle minecraft:happy_villager ~ ~1.4 ~ 0.3 0.3 0.3 0.02 20 force @a
