# Der Dealer raucht mit! (laeuft ALS der Dealer, ausgeloest von joint_smoked)
tag @s add ib_stoned
effect give @s minecraft:nausea 30 0 true
effect give @s minecraft:glowing 60 0 true
effect give @s minecraft:slowness 30 1 true
particle minecraft:campfire_cosy_smoke ~ ~1.5 ~ 0.4 0.5 0.4 0.01 40 force @a
playsound minecraft:entity.wandering_trader.drink_potion master @a ~ ~ ~ 1 0.8
tellraw @a[distance=..12] {"text":"[Der Dealer] Ohaaa... das ist gutes Zeug, Bruder... Fuer euch ab jetzt KUMPEL-PREISE!","color":"gold"}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:prismarine_shard",count:2,components:{"minecraft:custom_name":"Bro-Dollar","minecraft:item_model":"island_battle:bro_dollar"}},sell:{id:"minecraft:dried_kelp",count:1,components:{"minecraft:custom_name":"Joint","minecraft:item_model":"island_battle:joint","minecraft:food":{nutrition:2,saturation:0.4f,can_always_eat:1b},"minecraft:consumable":{consume_seconds:1.6f,animation:"eat",sound:"minecraft:entity.generic.eat",has_consume_particles:1b,on_consume_effects:[{type:"minecraft:apply_effects",effects:[{id:"minecraft:nausea",duration:200,amplifier:0},{id:"minecraft:luck",duration:1200,amplifier:0},{id:"minecraft:regeneration",duration:200,amplifier:0}],probability:1.0f}]}}},maxUses:9,rewardExp:0b}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:prismarine_shard",count:8,components:{"minecraft:custom_name":"Bro-Dollar","minecraft:item_model":"island_battle:bro_dollar"}},sell:{id:"minecraft:gold_block",count:1},maxUses:9,rewardExp:0b}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:dried_kelp",count:1},sell:{id:"minecraft:prismarine_shard",count:7,components:{"minecraft:custom_name":"Bro-Dollar","minecraft:item_model":"island_battle:bro_dollar"}},maxUses:9,rewardExp:0b}
