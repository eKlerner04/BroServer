# === HANF-STARTER-KIT (wird von start.mcfunction aufgerufen, fuer alle identisch) ===
give @s minecraft:iron_hoe 1
give @s minecraft:wheat_seeds[custom_name="Hanfsamen",item_model="island_battle:seeds"] 8
give @s minecraft:bone_meal 16
