# Wird ausgefuehrt wenn ein Spieler einen Joint konsumiert (via tech_joint Advancement)
advancement revoke @s only island_battle:tech_joint
# Rauchwolke + Sound
particle minecraft:campfire_cosy_smoke ~ ~1.5 ~ 0.4 0.4 0.4 0.01 40 force @a
playsound minecraft:entity.generic.extinguish_fire master @a ~ ~ ~ 0.5 0.6
# GEMEINSCHAFTSJOINT: Freunde in 5 Bloecken rauchen mit und bekommen die Effekte
execute as @a[distance=0.1..5] run effect give @s minecraft:luck 60 0 true
execute as @a[distance=0.1..5] run effect give @s minecraft:regeneration 10 0 true
execute as @a[distance=0.1..5] run effect give @s minecraft:nausea 8 0 true
tellraw @a[distance=0.1..5] {"text":"[BroServer] Gemeinschaftsjoint! Du rauchst mit...","color":"green"}
# TIERE RAUCHEN MIT: Schafe und Ziegen in der Naehe drehen durch
execute as @e[type=minecraft:sheep,distance=..6] run effect give @s minecraft:jump_boost 30 2 true
execute as @e[type=minecraft:sheep,distance=..6] run effect give @s minecraft:speed 30 1 true
execute as @e[type=minecraft:sheep,distance=..6] run effect give @s minecraft:glowing 30 0 true
execute as @e[type=minecraft:goat,distance=..6] run effect give @s minecraft:jump_boost 30 2 true
execute as @e[type=minecraft:goat,distance=..6] run effect give @s minecraft:speed 30 1 true
execute as @e[type=minecraft:goat,distance=..6] run effect give @s minecraft:glowing 30 0 true
execute as @e[type=minecraft:sheep,distance=..6] at @s run particle minecraft:campfire_cosy_smoke ~ ~1 ~ 0.3 0.3 0.3 0.01 15 force @a
execute as @e[type=minecraft:goat,distance=..6] at @s run particle minecraft:campfire_cosy_smoke ~ ~1 ~ 0.3 0.3 0.3 0.01 15 force @a
execute if entity @e[type=minecraft:sheep,distance=..6] run tellraw @s {"text":"[BroServer] Die Schafe sind jetzt auch high und springen wild rum!","color":"green"}
execute if entity @e[type=minecraft:goat,distance=..6] run tellraw @s {"text":"[BroServer] Die Ziege ist high... pass auf, die rammt gleich!","color":"green"}
