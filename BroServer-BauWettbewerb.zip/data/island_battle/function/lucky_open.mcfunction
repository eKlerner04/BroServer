# Gold-Lucky-Block geoeffnet (als Spieler an Spielerposition)
particle minecraft:totem_of_undying ~ ~1 ~ 0.6 0.8 0.6 0.2 60 force @a
particle minecraft:firework ~ ~1 ~ 0.5 0.6 0.5 0.1 30 force @a
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 1 1.3
kill @e[type=item,distance=..5,nbt={Item:{id:"minecraft:gold_block"}},limit=6]
execute store result score #coin luck_rng run random value 1..2
execute if score #coin luck_rng matches 2 run function island_battle:lucky_bad_roll
execute if score #coin luck_rng matches 1 run function island_battle:lucky_good_gold
