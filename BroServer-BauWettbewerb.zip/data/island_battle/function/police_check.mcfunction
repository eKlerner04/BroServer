# Kontrolle eines Spielers: Gemahlenes Gras oder Joints dabei?
execute if items entity @s container.* minecraft:green_dye run function island_battle:police_bust
execute unless items entity @s container.* minecraft:green_dye if items entity @s container.* minecraft:dried_kelp run function island_battle:police_bust
execute unless items entity @s container.* minecraft:green_dye unless items entity @s container.* minecraft:dried_kelp run tellraw @s {"text":"[POLIZEI] Alles sauber bei dir. Schoenen Tag noch.","color":"blue"}
