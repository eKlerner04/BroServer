# Ohne Fahrer: Motor aus (Speed 0). Mit Fahrer: Vollgas.
execute unless data entity @s Passengers[0] run attribute @s minecraft:movement_speed base set 0
execute if data entity @s Passengers[0] run attribute @s minecraft:movement_speed base set 0.45
