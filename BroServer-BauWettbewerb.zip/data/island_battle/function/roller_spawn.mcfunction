# MOTORROLLER: unsichtbares 2-Sitzer-Kamel + 3D-Scooter-Modell
summon minecraft:camel ~ ~ ~ {Tame:1b,PersistenceRequired:1b,Tags:["ib_roller"],CustomName:"Motorroller",equipment:{saddle:{id:"minecraft:saddle",count:1}}}
execute as @e[type=minecraft:camel,tag=ib_roller,distance=..2,limit=1,sort=nearest] run effect give @s minecraft:invisibility infinite 0 true
summon minecraft:item_display ~ ~ ~ {Tags:["ib_roller_disp"],item:{id:"minecraft:iron_nugget",count:1,components:{"minecraft:item_model":"island_battle:scooter"}},transformation:{translation:[0f,0f,0f],scale:[2.2f,2.2f,2.2f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
playsound minecraft:entity.camel.saddle master @a ~ ~ ~ 1 1
particle minecraft:poof ~ ~0.5 ~ 0.4 0.3 0.4 0.02 20 force @a
