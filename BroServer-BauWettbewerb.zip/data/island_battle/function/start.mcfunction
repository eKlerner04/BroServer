# === SPIEL STARTEN: Spieler auf Inseln verteilen (Admin) ===
# Voraussetzung: alle Spieler sind online (am besten in der Lobby)
tag @a remove ib_isl1
tag @a remove ib_isl2
tag @a remove ib_isl3
tag @a remove ib_isl4
tag @a add ib_pending
gamemode survival @a
# Jeder bekommt zufaellig EINE der identischen Inseln
execute as @r[tag=ib_pending] run function island_battle:assign_1
execute as @r[tag=ib_pending] run function island_battle:assign_2
execute as @r[tag=ib_pending] run function island_battle:assign_3
execute as @r[tag=ib_pending] run function island_battle:assign_4
tag @a remove ib_pending
# START-KIT: 5 Lucky Blocks fuer jeden (identisch = fair)
give @a minecraft:verdant_froglight 5
# HANF-KIT: Hacke, 8 Hanfsamen, Duenger (identisch = fair)
execute as @a run function island_battle:hemp_kit
title @a title {"text":"Los geht's!","color":"green"}
title @a subtitle {"text":"Baue das Schoenste auf deiner Insel!","color":"yellow"}
tellraw @a {"text":"[BroServer] Baut los! In den 3 Truhen ist fuer alle exakt das gleiche Material.","color":"aqua"}
tellraw @a {"text":"[BroServer] LUCKY BLOCKS: Du hast 5 gruene LUCKY BLOCKS (leuchtende Froglights)! Hinstellen und abbauen = Ueberraschung.","color":"gold"}
tellraw @a {"text":"[BroServer] Neue craften: 1 Diamant + 3 Glowstone. Diamanten gibt es mit Glueck aus Lucky Blocks!","color":"gold"}
tellraw @a {"text":"[BroServer] HANF-FARM: Am Teich ist dein Acker. Hanfsamen pflanzen, wachsen lassen, ernten!","color":"green"}
tellraw @a {"text":"[BroServer] Verarbeitung: 3 Blueten = 3 Papier | 2 Blueten = Hanffasern | 9 Blueten = Hanfballen","color":"green"}
tellraw @a {"text":"[BroServer] JOINT-KUNDE: Blueten im GRINDER (Steinsaege) mahlen -> mit Papier kalt drehen -> mit FEUERZEUG anzuenden!","color":"green"}
tellraw @a {"text":"[BroServer] Feuerzeug: 3 Kies craften. Tabak anbauen fuer den MISCH-JOINT (Papier+Gras+Tabak+Feuerzeug).","color":"green"}
tellraw @a {"text":"[BroServer] Der Dealer KAUFT auch an: Blueten, Gemahlenes und Tabak gegen Diamanten!","color":"yellow"}
tellraw @a {"text":"[BroServer] NEU: 5 Lucky-Stufen! GELB < GRUEN < LILA < AMETHYST < SCULK - je seltener, desto fetter die Beute.","color":"gold"}
tellraw @a {"text":"[BroServer] Alle 20 Minuten kommt DER DEALER bei dir vorbei - er nimmt Blueten, Diamanten und Fasern.","color":"yellow"}
tellraw @a {"text":"[BroServer] ACHTUNG: Lucky Blocks sind jetzt 50/50 - Glueck ODER Pech (TNT, Zombies, Hexen...). Oeffne sie NICHT neben deinem Bauwerk!","color":"red"}
tellraw @a {"text":"[BroServer] NEU: Joints wirken jetzt auf alle in der Naehe - und Schafe & Ziegen rauchen mit!","color":"green"}
tellraw @a {"text":"[BroServer] NEU: /trigger sethome speichert deine Position - /trigger home teleportiert dich dorthin. RUCKSACK: 8 Hanffasern + 1 Truhe!","color":"aqua"}
tellraw @a {"text":"[BroServer] NEUE WAEHRUNG: BRO-DOLLARS! Verkauf dem Dealer Blueten, Gras & Joints - kauf mit den Scheinen ein.","color":"aqua"}
tellraw @a {"text":"[BroServer] Der Dealer kommt jetzt zu ZUFALLSZEITEN mit ROTIERENDEM SORTIMENT (Farmer/Feinkost/Schwarzmarkt).","color":"yellow"}
tellraw @a {"text":"[BroServer] NEU: Haschplatte (6 Gemahlenes), Zigarette (Papier+Tabak+Feuerzeug), Packung (5 Papier+3 Tabak+Feuerzeug=8 Stk).","color":"green"}
tellraw @a {"text":"[BroServer] Rauchen hat jetzt Zufalls-Trips: manchmal UEBERFLIEGER, manchmal BAD TRIP...","color":"light_purple"}
tellraw @a {"text":"[BroServer] VORSICHT: Ab und zu kommt die POLIZEI! Wer Gras oder Joints dabei hat, kriegt eine Strafe - zahlen mit /trigger zahlen. Nicht zahlen = teurer + Verstaerkung!","color":"blue"}
function island_battle:quest_assign
tellraw @a {"text":"[BroServer] NEU: DER CHEMIKER kommt zu Zufallszeiten mit Labor-Produkten! TAGESAUFGABE jeden Morgen im Chat! SLOTS: /trigger slots (3 Bro-Dollars).","color":"aqua"}
tellraw @a {"text":"[BroServer] NEU: BRO-BAHN am Spawn (Speedboot auf Eis = Auto!), BRO-MOBIL (2-Sitzer-Kamel) beim Dealer, FRIEDENSPFEIFE (Stock+3 Gemahlenes+Mohn) = Frieden fuer ALLE. Tagesaufgabe abgeben: /trigger abgeben","color":"aqua"}
tellraw @a {"text":"[BroServer] NEU: SAMMELPUNKT hinterm Spawn ($-Block)! 5x am Tag kommt KUNDSCHAFT, die eure Ware fuer BRO-DOLLARS kauft - wird im Chat angekuendigt!","color":"gold"}
tellraw @a {"text":"[BroServer] NEU: Schwarzer MOTORROLLER (2-Sitzer!) - /trigger roller fuer 15 Bro-Dollars, 2 stehen an der BRO-BAHN. Neue Tiere: PINGUINE & GIRAFFEN!","color":"aqua"}
