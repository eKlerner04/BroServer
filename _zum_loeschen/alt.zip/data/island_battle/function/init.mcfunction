# Laeuft bei Serverstart und /reload
scoreboard objectives add ib_admin dummy
# Lucky Blocks: zaehlt abgebaute Bloecke pro Stufe und Spieler
scoreboard objectives add lucky_mine minecraft.mined:minecraft.gold_block
scoreboard objectives add lucky_mine_iron minecraft.mined:minecraft.iron_block
scoreboard objectives add lucky_mine_lapis minecraft.mined:minecraft.lapis_block
scoreboard objectives add lucky_mine_dia minecraft.mined:minecraft.diamond_block
scoreboard objectives add lucky_mine_neth minecraft.mined:minecraft.netherite_block
# Zufallswert fuer die Lucky-Block-Belohnung
scoreboard objectives add luck_rng dummy
# Dealer-Timer
scoreboard objectives add trader_timer dummy
