# === SPIEL STARTEN: Spieler auf Inseln verteilen (Admin) ===
# Voraussetzung: alle Spieler sind online (am besten in der Lobby)
tag @a remove ib_isl1
tag @a remove ib_isl2
tag @a remove ib_isl3
tag @a remove ib_isl4
tag @a add ib_pending
gamemode survival @a
# Jeder bekommt zufaellig EINE der identischen Inseln
execute as @r[tag=ib_pending] run function island_battle:assign_1
execute as @r[tag=ib_pending] run function island_battle:assign_2
execute as @r[tag=ib_pending] run function island_battle:assign_3
execute as @r[tag=ib_pending] run function island_battle:assign_4
tag @a remove ib_pending
# START-KIT: 5 Lucky Blocks fuer jeden (identisch = fair)
give @a minecraft:gold_block 5
# HANF-KIT: Hacke, 8 Hanfsamen, Duenger (identisch = fair)
execute as @a run function island_battle:hemp_kit
title @a title {"text":"Los geht's!","color":"green"}
title @a subtitle {"text":"Baue das Schoenste auf deiner Insel!","color":"yellow"}
tellraw @a {"text":"[BroServer] Baut los! In den 3 Truhen ist fuer alle exakt das gleiche Material.","color":"aqua"}
tellraw @a {"text":"[BroServer] LUCKY BLOCKS: Du hast 5 goldene Lucky Blocks! Hinstellen und abbauen = Ueberraschung.","color":"gold"}
tellraw @a {"text":"[BroServer] Neue craften: 1 Diamant + 3 Glowstone. Diamanten gibt es mit Glueck aus Lucky Blocks!","color":"gold"}
tellraw @a {"text":"[BroServer] HANF-FARM: Am Teich ist dein Acker. Hanfsamen pflanzen, wachsen lassen, ernten!","color":"green"}
tellraw @a {"text":"[BroServer] Verarbeitung: 3 Blueten = 3 Papier | 2 Blueten = Hanffasern | 9 Blueten = Hanfballen","color":"green"}
tellraw @a {"text":"[BroServer] JOINT-KUNDE: Blueten im GRINDER (Steinsaege) mahlen -> mit Papier kalt drehen -> mit FEUERZEUG anzuenden!","color":"green"}
tellraw @a {"text":"[BroServer] Feuerzeug: 3 Kies craften. Tabak anbauen fuer den MISCH-JOINT (Papier+Gras+Tabak+Feuerzeug).","color":"green"}
tellraw @a {"text":"[BroServer] Der Dealer KAUFT auch an: Blueten, Gemahlenes und Tabak gegen Diamanten!","color":"yellow"}
tellraw @a {"text":"[BroServer] NEU: 5 Lucky-Stufen! Eisen < Gold < Lapis < Dia < Netherite - je seltener, desto fetter die Beute.","color":"gold"}
tellraw @a {"text":"[BroServer] Alle 20 Minuten kommt DER DEALER bei dir vorbei - er nimmt Blueten, Diamanten und Fasern.","color":"yellow"}
tellraw @a {"text":"[BroServer] ACHTUNG: Lucky Blocks sind jetzt 50/50 - Glueck ODER Pech (TNT, Zombies, Hexen...). Oeffne sie NICHT neben deinem Bauwerk!","color":"red"}
tellraw @a {"text":"[BroServer] NEU: Joints wirken jetzt auf alle in der Naehe - und Schafe & Ziegen rauchen mit!","color":"green"}
