# Laeuft jeden Tick
# --- Lucky Blocks: hat jemand einen abgebaut? (pro Stufe) ---
execute as @a[scores={lucky_mine=1..}] at @s run function island_battle:lucky_open
execute as @a[scores={lucky_mine_iron=1..}] at @s run function island_battle:lucky_open_iron
execute as @a[scores={lucky_mine_lapis=1..}] at @s run function island_battle:lucky_open_lapis
execute as @a[scores={lucky_mine_dia=1..}] at @s run function island_battle:lucky_open_dia
execute as @a[scores={lucky_mine_neth=1..}] at @s run function island_battle:lucky_open_neth
# Zaehler zuruecksetzen
scoreboard players set @a lucky_mine 0
scoreboard players set @a lucky_mine_iron 0
scoreboard players set @a lucky_mine_lapis 0
scoreboard players set @a lucky_mine_dia 0
scoreboard players set @a lucky_mine_neth 0
# --- Dealer-Besuchs-Timer ---
function island_battle:trader_tick
