# Der Dealer - Admin-Sofort-Test
execute as @a at @s run function island_battle:trader_spawn
