# Der Dealer - Timer (wird jeden Tick vom Haupt-tick aufgerufen)
scoreboard players add #timer trader_timer 1
execute if score #timer trader_timer matches 23400 run tellraw @a {"text":"[BroServer] Der Dealer ist gleich in der Naehe...","color":"yellow"}
execute if score #timer trader_timer matches 24000.. as @a at @s run function island_battle:trader_spawn
execute if score #timer trader_timer matches 24000.. run scoreboard players set #timer trader_timer 0
