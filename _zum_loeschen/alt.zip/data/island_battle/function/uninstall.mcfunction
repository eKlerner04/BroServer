# Entfernt die Datapack-Objekte (vor dem Loeschen des Datapacks)
scoreboard objectives remove ib_admin
say [BroServer] Datapack-Objekte entfernt. Du kannst das Datapack jetzt loeschen.
scoreboard objectives remove lucky_mine
scoreboard objectives remove luck_rng
scoreboard objectives remove lucky_mine_iron
scoreboard objectives remove lucky_mine_lapis
scoreboard objectives remove lucky_mine_dia
scoreboard objectives remove lucky_mine_neth
scoreboard objectives remove trader_timer
