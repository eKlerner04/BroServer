$execute positioned $(x) $(y) $(z) run function island_battle:automat_go2
