execute unless data storage island_battle:am inv[0] run return 0
data modify storage island_battle:am cur set from storage island_battle:am inv[0]
data remove storage island_battle:am inv[0]
execute store result score #c kunde_t run data get storage island_battle:am cur.count
scoreboard players set #pr kunde_t 0
execute if data storage island_battle:am {cur:{id:"minecraft:wheat"}} run scoreboard players set #pr kunde_t 3
execute if data storage island_battle:am {cur:{id:"minecraft:green_dye"}} run scoreboard players set #pr kunde_t 5
execute if data storage island_battle:am {cur:{id:"minecraft:dried_kelp"}} run scoreboard players set #pr kunde_t 35
execute if data storage island_battle:am {cur:{id:"minecraft:beetroot"}} run scoreboard players set #pr kunde_t 4
execute if data storage island_battle:am {cur:{id:"minecraft:brick"}} run scoreboard players set #pr kunde_t 60
execute if data storage island_battle:am {cur:{id:"minecraft:bone"}} run scoreboard players set #pr kunde_t 10
scoreboard players operation #c kunde_t *= #pr kunde_t
scoreboard players operation #earn kunde_t += #c kunde_t
function island_battle:automat_loop
