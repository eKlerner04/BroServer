scoreboard players set #atimer kunde_t 0
execute store result storage island_battle:sp x int 1 run scoreboard players get #spx kunde_t
execute store result storage island_battle:sp y int 1 run scoreboard players get #spy kunde_t
execute store result storage island_battle:sp z int 1 run scoreboard players get #spz kunde_t
function island_battle:automat_go with storage island_battle:sp
