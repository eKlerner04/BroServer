# === SAMMELPUNKT (Treffpunkt fuer Kundschaft & Tiere) ===
fill -4 199 11 4 199 19 minecraft:smooth_quartz
fill -1 199 7 1 199 11 minecraft:smooth_quartz
setblock 0 200 15 minecraft:lodestone
setblock 0 203 15 minecraft:lantern[hanging=false]
fill -4 200 11 -4 200 19 minecraft:quartz_slab
fill 4 200 11 4 200 19 minecraft:quartz_slab
fill -3 200 19 3 200 19 minecraft:quartz_slab
setblock -3 201 12 minecraft:lantern
setblock 3 201 12 minecraft:lantern
setblock -3 200 12 minecraft:quartz_pillar
setblock 3 200 12 minecraft:quartz_pillar
particle minecraft:happy_villager 0 201 15 1 0.5 1 0.02 40 force @a
