execute as @a at @s run function island_battle:chem_spawn
