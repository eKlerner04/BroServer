execute store result score #cnext chem_t run random value 24000..48000
