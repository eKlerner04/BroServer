# Chemiker-Timer (zufaellig 20-40 Min)
scoreboard players add #ctimer chem_t 1
execute unless score #cnext chem_t = #cnext chem_t run function island_battle:chem_reroll
execute if score #ctimer chem_t >= #cnext chem_t run function island_battle:chem_visit
