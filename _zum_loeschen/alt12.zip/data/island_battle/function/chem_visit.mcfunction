tellraw @a {"text":"[BroServer] Der Chemiker macht seine Runde...","color":"aqua"}
execute as @a at @s run function island_battle:chem_spawn
scoreboard players set #ctimer chem_t 0
function island_battle:chem_reroll
