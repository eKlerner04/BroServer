# === HANF-STARTER-KIT (wird von start.mcfunction aufgerufen, fuer alle identisch) ===
give @s minecraft:iron_hoe 1
give @s minecraft:wheat_seeds[custom_name="Hanfsamen",item_model="island_battle:seeds"] 8
give @s minecraft:beetroot_seeds[custom_name="Tabak-Samen",item_model="island_battle:tobacco_seeds"] 4
give @s minecraft:bone_meal 16
give @s minecraft:stonecutter[custom_name="Grinder"] 1
give @s minecraft:flint[custom_name="Feuerzeug",item_model="island_battle:lighter"] 2
give @s minecraft:oak_boat[custom_name="Speedboot"] 1
