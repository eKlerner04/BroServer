# Eigenes gesetztes Zuhause (Koordinaten aus Scores)
execute store result storage island_battle:home x int 1 run scoreboard players get @s home_x
execute store result storage island_battle:home y int 1 run scoreboard players get @s home_y
execute store result storage island_battle:home z int 1 run scoreboard players get @s home_z
function island_battle:home_tp with storage island_battle:home
title @s actionbar {"text":"Zuhause!","color":"green"}
playsound minecraft:entity.enderman.teleport master @a ~ ~ ~ 1 1
