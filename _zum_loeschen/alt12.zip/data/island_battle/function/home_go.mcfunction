# Spieler hat /trigger home ausgefuehrt
execute if score @s home_x = @s home_x run function island_battle:home_custom
execute unless score @s home_x = @s home_x run function island_battle:home_island
