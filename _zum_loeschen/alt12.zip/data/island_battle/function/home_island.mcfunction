# Kein eigenes Zuhause gesetzt -> zur eigenen Insel (oder Lobby)
execute if entity @s[tag=ib_isl1] run tp @s 150 91 150
execute if entity @s[tag=ib_isl2] run tp @s -150 91 150
execute if entity @s[tag=ib_isl3] run tp @s 150 91 -150
execute if entity @s[tag=ib_isl4] run tp @s -150 91 -150
execute unless entity @s[tag=ib_isl1] unless entity @s[tag=ib_isl2] unless entity @s[tag=ib_isl3] unless entity @s[tag=ib_isl4] run tp @s 0 201 0
title @s actionbar {"text":"Zuhause!","color":"green"}
playsound minecraft:entity.enderman.teleport master @a ~ ~ ~ 1 1
