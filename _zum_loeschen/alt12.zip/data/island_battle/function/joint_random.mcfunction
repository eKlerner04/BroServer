# Zufalls-Trip: 1=Ueberflieger-High, 2=Bad Trip, 3-8=normal
execute store result score #trip luck_rng run random value 1..8
execute if score #trip luck_rng matches 1 run effect give @s minecraft:levitation 5 0 true
execute if score #trip luck_rng matches 1 run effect give @s minecraft:slow_falling 40 0 true
execute if score #trip luck_rng matches 1 run effect give @s minecraft:speed 60 1 true
execute if score #trip luck_rng matches 1 run title @s title {"text":"UEBERFLIEGER!","color":"gold"}
execute if score #trip luck_rng matches 1 run tellraw @s {"text":"[BroServer] Dieser Stoff... du hebst ab!","color":"gold"}
execute if score #trip luck_rng matches 2 run effect give @s minecraft:slowness 60 3 true
execute if score #trip luck_rng matches 2 run effect give @s minecraft:nausea 30 1 true
execute if score #trip luck_rng matches 2 run effect give @s minecraft:darkness 10 0 true
execute if score #trip luck_rng matches 2 run title @s title {"text":"BAD TRIP...","color":"dark_red"}
execute if score #trip luck_rng matches 2 run tellraw @s {"text":"[BroServer] Schlechter Trip! Deine Beine sind Pudding - 1 Minute Zeitlupe.","color":"dark_red"}
