# Tier-Ansturm am Sammelpunkt
summon minecraft:cat ~1 ~ ~1 {PersistenceRequired:1b,Tags:["ib_tier"]}
summon minecraft:parrot ~-1 ~1 ~1 {PersistenceRequired:1b,Tags:["ib_tier"]}
summon minecraft:frog ~1 ~ ~-1 {PersistenceRequired:1b,Tags:["ib_tier"]}
summon minecraft:rabbit ~-1 ~ ~-1 {PersistenceRequired:1b,Tags:["ib_tier"]}
summon minecraft:fox ~2 ~ ~ {PersistenceRequired:1b,Tags:["ib_tier"]}
summon minecraft:chicken ~-2 ~ ~ {PersistenceRequired:1b,Tags:["ib_tier"],CustomName:"Pinguin"}
summon minecraft:horse ~3 ~ ~2 {PersistenceRequired:1b,Tags:["ib_tier"],CustomName:"Giraffe",Variant:1}
tellraw @a {"text":"[SAMMELPUNKT] Tierischer Besuch! Ein paar neugierige Tiere schauen am Treffpunkt vorbei.","color":"green"}
playsound minecraft:entity.cat.ambient master @a
