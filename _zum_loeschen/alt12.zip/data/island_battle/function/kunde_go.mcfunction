$execute positioned $(x) $(y) $(z) run function island_battle:kunde_pick
