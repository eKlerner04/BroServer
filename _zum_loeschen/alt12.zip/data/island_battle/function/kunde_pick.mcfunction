execute if score #kart kunde_t matches 1 run function island_battle:kunde_1
execute if score #kart kunde_t matches 2 run function island_battle:kunde_2
execute if score #kart kunde_t matches 3 run function island_battle:kunde_3
execute if score #kart kunde_t matches 4 run function island_battle:kunde_4
execute if score #kart kunde_t matches 5 run function island_battle:kunde_5
execute if score #kart kunde_t matches 6 run function island_battle:kunde_6
