scoreboard players add #ktimer kunde_t 1
execute if score #ktimer kunde_t matches 4800.. run function island_battle:kunde_spawn
