# Diamanten-Regen
give @s minecraft:diamond 10
title @s actionbar {"text":"JACKPOT: 10 Diamanten!","color":"aqua"}
playsound minecraft:block.amethyst_block.chime master @a ~ ~ ~ 1 1
