# Bonus-Baumaterial
give @s minecraft:quartz_block 64
give @s minecraft:prismarine_bricks 32
title @s actionbar {"text":"Bonus-Baumaterial!","color":"green"}
