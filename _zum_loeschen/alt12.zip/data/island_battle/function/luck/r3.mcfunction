# Deko-Paket
give @s minecraft:lantern 16
give @s minecraft:glowstone 16
give @s minecraft:sea_lantern 8
title @s actionbar {"text":"Deko-Paket!","color":"light_purple"}
