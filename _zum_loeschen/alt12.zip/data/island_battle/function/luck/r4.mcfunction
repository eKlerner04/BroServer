# XP: +1 Level
xp add @s 1 levels
title @s actionbar {"text":"+1 XP-Level!","color":"green"}
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 1 1
