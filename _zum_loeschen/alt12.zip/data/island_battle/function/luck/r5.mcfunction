# Party-Boost
effect give @s minecraft:regeneration 8 1 true
effect give @s minecraft:absorption 30 2 true
effect give @s minecraft:haste 60 2 true
particle minecraft:totem_of_undying ~ ~1 ~ 1 1 1 0.3 100 force @a
title @s actionbar {"text":"Party-Boost!","color":"gold"}
