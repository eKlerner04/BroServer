# Haustier-Ueberraschung
summon minecraft:cat ~ ~1 ~ {PersistenceRequired:1b}
title @s actionbar {"text":"Ein Haustier!","color":"yellow"}
playsound minecraft:entity.cat.ambient master @a ~ ~ ~ 1 1
