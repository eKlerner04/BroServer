# Niete mit Humor: nur ein Brot ... aber Konfetti
give @s minecraft:bread 1
particle minecraft:heart ~ ~1 ~ 0.5 0.5 0.5 0.1 10 force @a
title @s actionbar {"text":"Niete... aber hier, ein Brot.","color":"gray"}
playsound minecraft:entity.villager.no master @a ~ ~ ~ 1 1
