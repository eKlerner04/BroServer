# Lucky-Nachschub: 2 neue Lucky Blocks + Regenbogen-Wolle
give @s minecraft:gold_block 2
give @s minecraft:red_wool 8
give @s minecraft:orange_wool 8
give @s minecraft:yellow_wool 8
give @s minecraft:lime_wool 8
give @s minecraft:light_blue_wool 8
give @s minecraft:purple_wool 8
title @s actionbar {"text":"2 neue Lucky Blocks + Regenbogen!","color":"gold"}
