# Potion-Paket
give @s minecraft:potion[potion_contents={potion:"minecraft:swiftness"}] 1
give @s minecraft:potion[potion_contents={potion:"minecraft:leaping"}] 1
give @s minecraft:splash_potion[potion_contents={potion:"minecraft:healing"}] 1
title @s actionbar {"text":"Potion-Paket!","color":"light_purple"}
playsound minecraft:block.brewing_stand.brew master @a ~ ~ ~ 1 1
