# GEZUENDETES TNT!
summon minecraft:tnt ~ ~ ~
summon minecraft:tnt ~1 ~ ~1
title @s title {"text":"TNT!!!","color":"red"}
playsound minecraft:entity.tnt.primed master @a ~ ~ ~ 1 1
tellraw @s {"text":"[BroServer] LAUF!!!","color":"red"}
