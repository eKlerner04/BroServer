# Zombie-Ueberfall
summon minecraft:zombie ~2 ~ ~ {PersistenceRequired:1b}
summon minecraft:zombie ~-2 ~ ~ {PersistenceRequired:1b}
summon minecraft:zombie ~ ~ ~2 {PersistenceRequired:1b}
title @s actionbar {"text":"Zombie-Ueberfall!","color":"red"}
playsound minecraft:entity.zombie.ambient master @a ~ ~ ~ 1 0.8
