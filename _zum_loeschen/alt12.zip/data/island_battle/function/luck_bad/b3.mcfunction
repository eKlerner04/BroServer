# Creeper-Besuch (Explosion schadet nur euch, nicht den Bauten)
summon minecraft:creeper ~2 ~ ~2
summon minecraft:creeper ~-2 ~ ~-2
title @s actionbar {"text":"Sssssss...","color":"dark_green"}
playsound minecraft:entity.creeper.primed master @a ~ ~ ~ 1 1
