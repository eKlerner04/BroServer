# Schlechter Stoff: Debuffs
effect give @s minecraft:nausea 15 0 true
effect give @s minecraft:blindness 8 0 true
effect give @s minecraft:slowness 15 1 true
title @s actionbar {"text":"Schlechter Stoff... dir wird uebel.","color":"dark_gray"}
playsound minecraft:entity.player.burp master @a ~ ~ ~ 1 0.7
