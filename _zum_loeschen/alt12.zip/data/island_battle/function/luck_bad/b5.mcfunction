# Silberfisch-Plage
summon minecraft:silverfish ~1 ~ ~
summon minecraft:silverfish ~-1 ~ ~
summon minecraft:silverfish ~ ~ ~1
summon minecraft:silverfish ~ ~ ~-1
title @s actionbar {"text":"Igitt, Silberfische!","color":"gray"}
playsound minecraft:entity.silverfish.ambient master @a ~ ~ ~ 1 1
