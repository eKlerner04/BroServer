# Blitzschlag!
summon minecraft:lightning_bolt ~ ~ ~
title @s actionbar {"text":"ZAPP!","color":"yellow"}
