# Hexen-Besuch
summon minecraft:witch ~2 ~ ~2 {PersistenceRequired:1b}
title @s actionbar {"text":"Eine Hexe! Sie wirft mit Traenken!","color":"dark_purple"}
playsound minecraft:entity.witch.ambient master @a ~ ~ ~ 1 1
