# Diamant-Belohnung 1: Dia-Ruestung Teil 1
give @s minecraft:diamond_helmet 1
give @s minecraft:diamond_boots 1
title @s actionbar {"text":"Dia-Ruestung Teil 1!","color":"aqua"}
playsound minecraft:item.armor.equip_diamond master @a ~ ~ ~ 1 1
particle minecraft:end_rod ~ ~1 ~ 0.5 0.6 0.5 0.1 30 force @a
