# Diamant-Belohnung 2: Dia-Brustpanzer
give @s minecraft:diamond_chestplate 1
title @s actionbar {"text":"Dia-Brustpanzer!","color":"aqua"}
playsound minecraft:item.armor.equip_diamond master @a ~ ~ ~ 1 0.9
particle minecraft:end_rod ~ ~1 ~ 0.5 0.6 0.5 0.1 30 force @a
