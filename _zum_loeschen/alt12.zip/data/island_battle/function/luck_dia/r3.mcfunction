# Diamant-Belohnung 3: Dia-Werkzeug
give @s minecraft:diamond_sword 1
give @s minecraft:diamond_pickaxe 1
title @s actionbar {"text":"Dia-Werkzeug!","color":"aqua"}
playsound minecraft:block.amethyst_block.chime master @a ~ ~ ~ 1 1
particle minecraft:end_rod ~ ~1 ~ 0.5 0.6 0.5 0.1 30 force @a
