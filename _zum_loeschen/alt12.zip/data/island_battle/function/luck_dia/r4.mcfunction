# Diamant-Belohnung 4: Diamanten-Jackpot
give @s minecraft:diamond 5
give @s minecraft:gold_block 2
title @s actionbar {"text":"Diamanten-Jackpot!","color":"aqua"}
playsound minecraft:block.amethyst_block.chime master @a ~ ~ ~ 1 1.2
particle minecraft:firework ~ ~1 ~ 0.5 0.6 0.5 0.1 40 force @a
