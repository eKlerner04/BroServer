# Sehr kaputte Elytra + Raketen (nur noch wenige Fluege!)
give @s minecraft:elytra[damage=420] 1
give @s minecraft:firework_rocket 16
title @s actionbar {"text":"Kaputte Elytra! Nutze sie weise...","color":"aqua"}
playsound minecraft:item.armor.equip_elytra master @a ~ ~ ~ 1 1
