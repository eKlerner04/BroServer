# Eisen-Belohnung 1: Steine & Brot
give @s minecraft:cobblestone 16
give @s minecraft:bread 8
title @s actionbar {"text":"Eisen-Fund: Steine & Brot","color":"gray"}
playsound minecraft:entity.item.pickup master @a ~ ~ ~ 1 0.9
particle minecraft:poof ~ ~1 ~ 0.4 0.5 0.4 0.05 15 force @a
