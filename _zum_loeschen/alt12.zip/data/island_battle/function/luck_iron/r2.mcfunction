# Eisen-Belohnung 2: Leder-Ruestung
give @s minecraft:leather_helmet 1
give @s minecraft:leather_chestplate 1
title @s actionbar {"text":"Leder-Ruestung!","color":"gold"}
playsound minecraft:item.armor.equip_leather master @a ~ ~ ~ 1 1
particle minecraft:crit ~ ~1 ~ 0.4 0.5 0.4 0.1 20 force @a
