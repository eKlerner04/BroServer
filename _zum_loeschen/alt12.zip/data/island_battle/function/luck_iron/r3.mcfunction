# Eisen-Belohnung 3: Eisenschwert & Fackeln
give @s minecraft:iron_sword 1
give @s minecraft:torch 8
title @s actionbar {"text":"Eisenschwert!","color":"white"}
playsound minecraft:item.armor.equip_iron master @a ~ ~ ~ 1 1
particle minecraft:crit ~ ~1 ~ 0.4 0.5 0.4 0.1 20 force @a
