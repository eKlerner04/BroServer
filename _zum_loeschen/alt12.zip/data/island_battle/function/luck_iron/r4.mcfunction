# Eisen-Belohnung 4: Lucky-Nachschub
give @s minecraft:gold_block 2
title @s actionbar {"text":"2 Gold-Lucky-Blocks!","color":"yellow"}
playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~ 1 1.2
particle minecraft:happy_villager ~ ~1 ~ 0.5 0.6 0.5 0.1 25 force @a
