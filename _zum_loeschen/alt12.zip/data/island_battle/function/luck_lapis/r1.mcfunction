# Lapis-Belohnung 1: XP-Level
xp add @s 5 levels
title @s actionbar {"text":"+5 Level!","color":"green"}
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 1 1
particle minecraft:enchant ~ ~1 ~ 0.5 0.8 0.5 0.5 40 force @a
