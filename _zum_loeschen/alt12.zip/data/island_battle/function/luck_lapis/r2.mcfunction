# Lapis-Belohnung 2: Erfahrungsflaschen
give @s minecraft:experience_bottle 8
title @s actionbar {"text":"8 Erfahrungsflaschen!","color":"green"}
playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~ 1 1
particle minecraft:enchant ~ ~1 ~ 0.5 0.8 0.5 0.5 40 force @a
