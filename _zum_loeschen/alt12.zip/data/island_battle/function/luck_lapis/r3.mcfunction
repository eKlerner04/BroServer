# Lapis-Belohnung 3: Zaubertisch & Regale
give @s minecraft:enchanting_table 1
give @s minecraft:bookshelf 4
title @s actionbar {"text":"Zauber-Ecke!","color":"light_purple"}
playsound minecraft:block.enchantment_table.use master @a ~ ~ ~ 1 1
particle minecraft:enchant ~ ~1 ~ 0.6 0.8 0.6 0.5 50 force @a
