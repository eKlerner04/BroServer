# Lapis-Belohnung 4: Lapis & Buch
give @s minecraft:lapis_lazuli 16
give @s minecraft:book 1
title @s actionbar {"text":"Lapis & Buch!","color":"blue"}
playsound minecraft:entity.item.pickup master @a ~ ~ ~ 1 1.1
particle minecraft:bubble_pop ~ ~1 ~ 0.4 0.5 0.4 0.1 25 force @a
