# Verzauberter Bogen + Pfeile
give @s minecraft:bow[enchantments={"minecraft:power":3,"minecraft:punch":1}] 1
give @s minecraft:arrow 32
title @s actionbar {"text":"Verzauberter Bogen!","color":"light_purple"}
playsound minecraft:block.enchantment_table.use master @a ~ ~ ~ 1 1
