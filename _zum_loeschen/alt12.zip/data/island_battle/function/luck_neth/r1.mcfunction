# Netherite-Belohnung 1: Helm
give @s minecraft:netherite_helmet 1
title @s actionbar {"text":"NETHERITE-HELM!","color":"dark_red"}
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1
particle minecraft:totem_of_undying ~ ~1 ~ 0.6 0.8 0.6 0.2 60 force @a
