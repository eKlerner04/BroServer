# Netherite-Belohnung 2: Brustpanzer
give @s minecraft:netherite_chestplate 1
title @s actionbar {"text":"NETHERITE-PANZER!","color":"dark_red"}
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1
particle minecraft:totem_of_undying ~ ~1 ~ 0.6 0.8 0.6 0.2 60 force @a
