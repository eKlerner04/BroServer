# Netherite-Belohnung 3: Schwert
give @s minecraft:netherite_sword 1
title @s actionbar {"text":"NETHERITE-SCHWERT!","color":"dark_red"}
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1
particle minecraft:totem_of_undying ~ ~1 ~ 0.6 0.8 0.6 0.2 60 force @a
