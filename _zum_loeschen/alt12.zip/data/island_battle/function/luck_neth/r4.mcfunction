# Netherite-Belohnung 4: Mega-Jackpot
give @s minecraft:netherite_ingot 2
give @s minecraft:diamond 10
title @s actionbar {"text":"MEGA-JACKPOT!","color":"dark_red"}
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1
particle minecraft:totem_of_undying ~ ~1 ~ 0.6 0.8 0.6 0.2 60 force @a
