give @s minecraft:diamond 16
title @s actionbar {"text":"16 DIAMANTEN!","color":"aqua"}
