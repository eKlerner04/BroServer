give @s minecraft:netherite_chestplate 1
give @s minecraft:netherite_sword 1
title @s actionbar {"text":"NETHERITE-AUSRUESTUNG!","color":"dark_purple"}
