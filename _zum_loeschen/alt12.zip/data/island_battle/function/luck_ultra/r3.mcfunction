give @s minecraft:elytra 1
give @s minecraft:firework_rocket 32
title @s actionbar {"text":"NEUE ELYTRA + RAKETEN!","color":"aqua"}
