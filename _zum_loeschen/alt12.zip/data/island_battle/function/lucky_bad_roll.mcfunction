# PECH gehabt: eine von 7 fiesen Ueberraschungen
execute store result score #b luck_rng run random value 1..7
execute if score #b luck_rng matches 1 run function island_battle:luck_bad/b1
execute if score #b luck_rng matches 2 run function island_battle:luck_bad/b2
execute if score #b luck_rng matches 3 run function island_battle:luck_bad/b3
execute if score #b luck_rng matches 4 run function island_battle:luck_bad/b4
execute if score #b luck_rng matches 5 run function island_battle:luck_bad/b5
execute if score #b luck_rng matches 6 run function island_battle:luck_bad/b6
execute if score #b luck_rng matches 7 run function island_battle:luck_bad/b7
