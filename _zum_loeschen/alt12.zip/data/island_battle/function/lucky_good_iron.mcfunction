execute store result score #r luck_rng run random value 1..4
execute if score #r luck_rng matches 1 run function island_battle:luck_iron/r1
execute if score #r luck_rng matches 2 run function island_battle:luck_iron/r2
execute if score #r luck_rng matches 3 run function island_battle:luck_iron/r3
execute if score #r luck_rng matches 4 run function island_battle:luck_iron/r4
