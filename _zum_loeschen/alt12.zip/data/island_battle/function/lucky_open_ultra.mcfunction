# ULTRA-Lucky-Block: garantiert gut!
particle minecraft:totem_of_undying ~ ~1 ~ 0.8 1 0.8 0.3 100 force @a
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1
kill @e[type=item,distance=..5,nbt={Item:{id:"minecraft:sponge"}},limit=6]
execute store result score #r luck_rng run random value 1..4
execute if score #r luck_rng matches 1 run function island_battle:luck_ultra/r1
execute if score #r luck_rng matches 2 run function island_battle:luck_ultra/r2
execute if score #r luck_rng matches 3 run function island_battle:luck_ultra/r3
execute if score #r luck_rng matches 4 run function island_battle:luck_ultra/r4
