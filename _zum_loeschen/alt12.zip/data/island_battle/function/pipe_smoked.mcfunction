# FRIEDENSPFEIFE geraucht: Frieden fuer den ganzen Server!
advancement revoke @s only island_battle:tech_pipe
tellraw @a [{"text":"[FRIEDENSPFEIFE] ","color":"gold","bold":true},{"selector":"@s","color":"yellow"},{"text":" hat die Friedenspfeife geraucht. FRIEDEN AUF DEM SERVER!","color":"gold"}]
effect give @a minecraft:regeneration 30 1 true
effect give @a minecraft:absorption 120 1 true
effect give @a minecraft:luck 120 0 true
effect give @a minecraft:glowing 15 0 true
title @a title {"text":"FRIEDEN","color":"gold"}
title @a subtitle {"text":"Die Friedenspfeife wurde geraucht","color":"yellow"}
# Die Polizei laesst alle in Ruhe: Fahndungen aufgehoben, Polizisten ziehen ab
tag @a remove ib_wanted
kill @e[type=minecraft:vindicator,tag=ib_cop]
tellraw @a {"text":"[POLIZEI] Na gut... Friedenspfeife ist Friedenspfeife. Alle Verfahren eingestellt.","color":"blue"}
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 0.9
particle minecraft:campfire_signal_smoke ~ ~2 ~ 0.5 1 0.5 0.02 60 force @a
