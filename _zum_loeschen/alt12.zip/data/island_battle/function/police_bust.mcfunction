# ERWISCHT: Mahnung + Strafe
execute if entity @s[tag=ib_wanted] run return 0
tag @s add ib_wanted
scoreboard players set @s police_fine 5
scoreboard players set @s police_t 6000
summon minecraft:vindicator ~3 ~ ~3 {PersistenceRequired:1b,CustomName:"Polizist",Tags:["ib_cop"]}
title @s title {"text":"ERWISCHT!","color":"blue"}
title @s subtitle {"text":"Illegale Substanzen gefunden!","color":"red"}
# Fund-Protokoll: was wurde gefunden?
execute store result score @s pol_g run clear @s minecraft:green_dye 0
execute store result score @s pol_j run clear @s minecraft:dried_kelp 0
execute store result score @s pol_h run clear @s minecraft:brick 0
tellraw @s {"text":"[POLIZEI] Durchsuchungsprotokoll - gefunden bei dir:","color":"blue"}
execute if score @s pol_g matches 1.. run tellraw @s [{"text":"   > Gemahlenes Gras: ","color":"gray"},{"score":{"name":"@s","objective":"pol_g"},"color":"green"},{"text":" Stueck","color":"gray"}]
execute if score @s pol_j matches 1.. run tellraw @s [{"text":"   > Joints: ","color":"gray"},{"score":{"name":"@s","objective":"pol_j"},"color":"green"},{"text":" Stueck","color":"gray"}]
execute if score @s pol_h matches 1.. run tellraw @s [{"text":"   > Haschplatten: ","color":"gray"},{"score":{"name":"@s","objective":"pol_h"},"color":"green"},{"text":" Stueck","color":"gray"}]
tellraw @s {"text":"[POLIZEI] MAHNUNG: Zahle 5 Bro-Dollars Strafe mit /trigger zahlen - du hast 5 Minuten!","color":"red"}
tellraw @s {"text":"[POLIZEI] Sonst wird es teurer und wir kommen mit Verstaerkung...","color":"red"}
playsound minecraft:entity.vindicator.ambient master @a ~ ~ ~ 1 0.8
