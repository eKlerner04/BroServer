# Kontrolle: Gras, Joints oder Hasch dabei?
tag @s remove ib_dirty
execute if items entity @s container.* minecraft:green_dye run tag @s add ib_dirty
execute if items entity @s container.* minecraft:dried_kelp run tag @s add ib_dirty
execute if items entity @s container.* minecraft:brick run tag @s add ib_dirty
execute if entity @s[tag=ib_dirty] run function island_battle:police_bust
execute unless entity @s[tag=ib_dirty] run tellraw @s {"text":"[POLIZEI] Alles sauber bei dir. Schoenen Tag noch.","color":"blue"}
tag @s remove ib_dirty
