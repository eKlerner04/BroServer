# Frist abgelaufen: Strafe verdoppeln (max 40), Verstaerkung
scoreboard players operation @s police_fine += @s police_fine
execute if score @s police_fine matches 41.. run scoreboard players set @s police_fine 40
scoreboard players set @s police_t 6000
summon minecraft:vindicator ~3 ~ ~-3 {PersistenceRequired:1b,CustomName:"Polizist",Tags:["ib_cop"]}
summon minecraft:vindicator ~-3 ~ ~3 {PersistenceRequired:1b,CustomName:"Polizist",Tags:["ib_cop"]}
title @s title {"text":"VERSTAERKUNG!","color":"dark_red"}
tellraw @s [{"text":"[POLIZEI] Frist verpasst! Neue Strafe: ","color":"dark_red"},{"score":{"name":"@s","objective":"police_fine"},"color":"gold"},{"text":" Bro-Dollars. /trigger zahlen - SOFORT!","color":"dark_red"}]
playsound minecraft:entity.vindicator.ambient master @a ~ ~ ~ 1 0.6
