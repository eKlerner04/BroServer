# Versuch zu zahlen
execute unless entity @s[tag=ib_wanted] run tellraw @s {"text":"[POLIZEI] Du hast keine offene Strafe.","color":"blue"}
execute unless entity @s[tag=ib_wanted] run return 0
execute store result score #cash police_timer run clear @s minecraft:prismarine_shard 0
execute if score #cash police_timer < @s police_fine run tellraw @s [{"text":"[POLIZEI] Zu wenig Bro-Dollars! Du brauchst ","color":"red"},{"score":{"name":"@s","objective":"police_fine"},"color":"gold"},{"text":". Verkauf was beim Dealer!","color":"red"}]
execute if score #cash police_timer >= @s police_fine run function island_battle:police_pay_ok
