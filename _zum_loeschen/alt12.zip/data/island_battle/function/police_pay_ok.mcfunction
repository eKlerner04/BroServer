# Strafe abbuchen (Macro) und Frieden
execute store result storage island_battle:police fine int 1 run scoreboard players get @s police_fine
function island_battle:police_take with storage island_battle:police
tag @s remove ib_wanted
kill @e[type=minecraft:vindicator,tag=ib_cop,distance=..48]
title @s title {"text":"Strafe bezahlt","color":"green"}
tellraw @s {"text":"[POLIZEI] Schon gut. Und lass dich nicht nochmal erwischen...","color":"blue"}
playsound minecraft:entity.villager.yes master @a ~ ~ ~ 1 1
