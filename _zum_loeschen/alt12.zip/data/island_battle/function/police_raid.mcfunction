# RAZZIA: jeder Spieler wird kontrolliert
tellraw @a {"text":"[POLIZEI] KONTROLLE! Taschen leeren, alle mal stehen bleiben...","color":"blue"}
playsound minecraft:entity.iron_golem.repair master @a
execute as @a at @s run function island_battle:police_check
scoreboard players set #ptimer police_timer 0
function island_battle:police_reroll
