execute store result score #pnext police_timer run random value 18000..36000
