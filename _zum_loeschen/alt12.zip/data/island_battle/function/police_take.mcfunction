$clear @s minecraft:prismarine_shard $(fine)
