# Polizei-Timer (jeden Tick)
scoreboard players add #ptimer police_timer 1
execute unless score #pnext police_timer = #pnext police_timer run function island_battle:police_reroll
execute if score #ptimer police_timer >= #pnext police_timer run function island_battle:police_raid
# Zahlungsfrist fuer Gesuchte herunterzaehlen
execute as @a[tag=ib_wanted] run scoreboard players remove @s police_t 1
execute as @a[tag=ib_wanted,scores={police_t=..0}] at @s run function island_battle:police_escalate
