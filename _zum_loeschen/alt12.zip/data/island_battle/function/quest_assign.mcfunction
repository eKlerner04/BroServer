# Neue Tagesaufgabe auswuerfeln
execute store result score #qid quest_t run random value 1..8
execute if score #qid quest_t matches 1 run function island_battle:quest_say_1
execute if score #qid quest_t matches 2 run function island_battle:quest_say_2
execute if score #qid quest_t matches 3 run function island_battle:quest_say_3
execute if score #qid quest_t matches 4 run function island_battle:quest_say_4
execute if score #qid quest_t matches 5 run function island_battle:quest_say_5
execute if score #qid quest_t matches 6 run function island_battle:quest_say_6
execute if score #qid quest_t matches 7 run function island_battle:quest_say_7
execute if score #qid quest_t matches 8 run function island_battle:quest_say_8
