# Abgabe-Pruefung: oak_log
execute if items entity @s container.* minecraft:oak_log run function island_battle:quest_win_2
execute unless items entity @s container.* minecraft:oak_log run tellraw @s {"text":"[TAGESAUFGABE] Das gesuchte Item ist nicht in deinem Inventar - weiter suchen!","color":"gray"}
