# Abgabe-Pruefung: bread
execute if items entity @s container.* minecraft:bread run function island_battle:quest_win_3
execute unless items entity @s container.* minecraft:bread run tellraw @s {"text":"[TAGESAUFGABE] Das gesuchte Item ist nicht in deinem Inventar - weiter suchen!","color":"gray"}
