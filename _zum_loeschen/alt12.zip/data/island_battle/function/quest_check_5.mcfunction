# Abgabe-Pruefung: white_wool
execute if items entity @s container.* minecraft:white_wool run function island_battle:quest_win_5
execute unless items entity @s container.* minecraft:white_wool run tellraw @s {"text":"[TAGESAUFGABE] Das gesuchte Item ist nicht in deinem Inventar - weiter suchen!","color":"gray"}
