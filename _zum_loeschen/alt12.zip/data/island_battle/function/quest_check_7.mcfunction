# Abgabe-Pruefung: ladder
execute if items entity @s container.* minecraft:ladder run function island_battle:quest_win_7
execute unless items entity @s container.* minecraft:ladder run tellraw @s {"text":"[TAGESAUFGABE] Das gesuchte Item ist nicht in deinem Inventar - weiter suchen!","color":"gray"}
