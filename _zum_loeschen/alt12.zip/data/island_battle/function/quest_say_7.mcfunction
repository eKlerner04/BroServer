tellraw @a [{"text":"[TAGESAUFGABE] ","color":"gold","bold":true},{"text":"Besorge bis zum Abend: eine LEITER! Belohnung: MEGA-JOINT + ULTRA-LUCKY-BLOCK. Nicht geschafft? Kein Stress.","color":"yellow"}]
playsound minecraft:block.bell.use master @a
