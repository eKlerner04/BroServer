execute store result score #cash police_timer run clear @s minecraft:prismarine_shard 0
execute if score #cash police_timer matches ..14 run tellraw @s {"text":"[MOTORROLLER] Kostet 15 Bro-Dollars - verkauf erst was!","color":"red"}
execute if score #cash police_timer matches 15.. run function island_battle:roller_buy_ok
