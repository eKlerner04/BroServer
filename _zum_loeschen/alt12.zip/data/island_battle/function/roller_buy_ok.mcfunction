clear @s minecraft:prismarine_shard 15
function island_battle:roller_spawn
tellraw @s {"text":"[MOTORROLLER] Dein schwarzer Roller steht bereit - aufsitzen! (2 Plaetze: einfach beide draufklicken)","color":"green"}
