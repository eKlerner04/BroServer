# Speichert die aktuelle Position als Zuhause
execute store result score @s home_x run data get entity @s Pos[0]
execute store result score @s home_y run data get entity @s Pos[1]
execute store result score @s home_z run data get entity @s Pos[2]
tellraw @s {"text":"[BroServer] Zuhause gesetzt! Zurueck mit: /trigger home","color":"green"}
playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.5
