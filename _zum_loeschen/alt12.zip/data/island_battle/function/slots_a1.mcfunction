execute as @a[tag=ib_slotting] run title @s title {"text":"[ 7 | $ | X ]","color":"yellow"}
execute as @a[tag=ib_slotting] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 0.8
