execute as @a[tag=ib_slotting] run title @s title {"text":"[ $ | X | 7 ]","color":"yellow"}
execute as @a[tag=ib_slotting] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.0
