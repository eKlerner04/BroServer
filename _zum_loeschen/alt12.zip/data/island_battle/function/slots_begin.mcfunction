clear @s minecraft:prismarine_shard 3
tag @s add ib_slotting
execute store result score @s slots_res run random value 1..100
title @s times 0 12 4
title @s subtitle {"text":"- SLOTS -","color":"gold"}
title @s title {"text":"[ ? | ? | ? ]","color":"yellow"}
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 0.7
schedule function island_battle:slots_a1 8t append
schedule function island_battle:slots_a2 16t append
schedule function island_battle:slots_a3 24t append
schedule function island_battle:slots_a4 32t append
schedule function island_battle:slots_result 44t append
