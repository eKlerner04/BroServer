# Knopf am Slotautomaten (23 201 0) gedrueckt?
execute if block 23 201 0 minecraft:stone_button[powered=true] if score #btn slots_state matches 0 run function island_battle:slots_pressed
execute if block 23 201 0 minecraft:stone_button[powered=true] run scoreboard players set #btn slots_state 1
execute unless block 23 201 0 minecraft:stone_button[powered=true] run scoreboard players set #btn slots_state 0
