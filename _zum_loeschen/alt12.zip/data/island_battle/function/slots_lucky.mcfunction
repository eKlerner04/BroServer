give @s minecraft:verdant_froglight 1
tellraw @s {"text":"[SLOTS] LUCKY BLOCK gewonnen!","color":"gold"}
playsound minecraft:ui.toast.challenge_complete master @s
