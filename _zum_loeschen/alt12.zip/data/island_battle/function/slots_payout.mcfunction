execute if score @s slots_res matches 1..50 run title @s title {"text":"[ X | O | 7 ]","color":"red"}
execute if score @s slots_res matches 1..50 run tellraw @s {"text":"[SLOTS] Niete... die Scheine sind weg.","color":"gray"}
execute if score @s slots_res matches 1..50 run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.5
execute if score @s slots_res matches 51..75 run title @s title {"text":"[ $ | $ | X ]","color":"yellow"}
execute if score @s slots_res matches 51..75 run function island_battle:slots_w2
execute if score @s slots_res matches 76..90 run title @s title {"text":"[ $ | $ | $ ]","color":"green"}
execute if score @s slots_res matches 76..90 run function island_battle:slots_w5
execute if score @s slots_res matches 91..97 run title @s title {"text":"[ 7 | 7 | $ ]","color":"green"}
execute if score @s slots_res matches 91..97 run function island_battle:slots_w10
execute if score @s slots_res matches 98..99 run title @s title {"text":"[ L | L | L ]","color":"gold"}
execute if score @s slots_res matches 98..99 run function island_battle:slots_lucky
execute if score @s slots_res matches 100 run function island_battle:slots_jackpot
