# Slotautomat: 3 Bro-Dollars Einsatz
execute if entity @s[tag=ib_slotting] run return 0
execute store result score #cash police_timer run clear @s minecraft:prismarine_shard 0
execute if score #cash police_timer matches ..2 run tellraw @s {"text":"[SLOTS] Du brauchst 3 Bro-Dollars Einsatz!","color":"red"}
execute if score #cash police_timer matches ..2 run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.6
execute if score #cash police_timer matches 3.. run function island_battle:slots_begin
