execute positioned 24 201 0 as @p[distance=..5] run function island_battle:slots_play
