execute as @a[tag=ib_slotting] at @s run function island_battle:slots_payout
tag @a remove ib_slotting
