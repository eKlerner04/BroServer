clear @s minecraft:prismarine_shard 3
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 0.8
execute store result score #slot luck_rng run random value 1..100
execute if score #slot luck_rng matches 1..50 run tellraw @s {"text":"[SLOTS] Niete... die Scheine sind weg.","color":"gray"}
execute if score #slot luck_rng matches 51..75 run function island_battle:slots_w2
execute if score #slot luck_rng matches 76..90 run function island_battle:slots_w5
execute if score #slot luck_rng matches 91..97 run function island_battle:slots_w10
execute if score #slot luck_rng matches 98..99 run function island_battle:slots_lucky
execute if score #slot luck_rng matches 100 run function island_battle:slots_jackpot
