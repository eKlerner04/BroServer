give @s minecraft:prismarine_shard[custom_name="Bro-Dollar",item_model="island_battle:bro_dollar"] 10
tellraw @s {"text":"[SLOTS] FETTER GEWINN: 10 Bro-Dollars!","color":"green"}
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.4
