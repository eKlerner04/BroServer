give @s minecraft:prismarine_shard[custom_name="Bro-Dollar",item_model="island_battle:bro_dollar"] 2
tellraw @s {"text":"[SLOTS] 2 Dollar zurueck - fast!","color":"yellow"}
