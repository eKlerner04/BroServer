give @s minecraft:prismarine_shard[custom_name="Bro-Dollar",item_model="island_battle:bro_dollar"] 5
tellraw @s {"text":"[SLOTS] GEWONNEN: 5 Bro-Dollars!","color":"green"}
playsound minecraft:entity.player.levelup master @s
