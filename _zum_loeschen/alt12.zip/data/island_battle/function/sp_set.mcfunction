# Sammelpunkt an aktuelle Position verlegen
execute store result score #spx kunde_t run data get entity @s Pos[0]
execute store result score #spy kunde_t run data get entity @s Pos[1]
execute store result score #spz kunde_t run data get entity @s Pos[2]
tellraw @a [{"text":"[SAMMELPUNKT] ","color":"gold","bold":true},{"selector":"@s","color":"yellow"},{"text":" hat den Sammelpunkt hierher verlegt - die Kundschaft kommt ab jetzt hier vorbei!","color":"yellow"}]
particle minecraft:happy_villager ~ ~1 ~ 1 1 1 0.05 60 force @a
playsound minecraft:block.bell.use master @a
