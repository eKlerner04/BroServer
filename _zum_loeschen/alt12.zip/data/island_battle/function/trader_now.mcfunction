# Admin: Dealer sofort spawnen
function island_battle:trader_reroll
execute as @a at @s run function island_battle:trader_spawn
scoreboard players set #timer trader_timer 0
