# Naechste Dealer-Zeit + Sortiment auswuerfeln
execute store result score #next trader_timer run random value 12000..30000
scoreboard players operation #warn trader_timer = #next trader_timer
scoreboard players remove #warn trader_timer 600
execute store result score #sort trader_timer run random value 1..3
