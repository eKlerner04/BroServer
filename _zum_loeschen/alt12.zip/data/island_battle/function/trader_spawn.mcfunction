# Der Dealer erscheint (Sortiment wurde in trader_visit gerollt)
execute if score #sort trader_timer matches 1 run function island_battle:trader_spawn_a
execute if score #sort trader_timer matches 2 run function island_battle:trader_spawn_b
execute if score #sort trader_timer matches 3 run function island_battle:trader_spawn_c
