# Der Dealer - Timer (jeden Tick), zufaellige Besuchszeiten
scoreboard players add #timer trader_timer 1
execute unless score #next trader_timer = #next trader_timer run function island_battle:trader_reroll
execute if score #timer trader_timer = #warn trader_timer run tellraw @a {"text":"[BroServer] Der Dealer ist gleich in der Naehe...","color":"yellow"}
execute if score #timer trader_timer >= #next trader_timer run function island_battle:trader_visit
