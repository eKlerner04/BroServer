# Der Dealer besucht jeden Spieler
execute as @a at @s run function island_battle:trader_spawn
scoreboard players set #timer trader_timer 0
function island_battle:trader_reroll
