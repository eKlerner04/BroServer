# === VORFUEHR-ECKE an der Lobby (Terrasse Richtung Osten, y=199) ===
# Terrasse
fill 8 199 -4 24 199 4 minecraft:smooth_quartz
# Gelaender (Glasscheiben) rundum
fill 8 200 -4 24 200 -4 minecraft:glass_pane
fill 8 200 4 24 200 4 minecraft:glass_pane
fill 24 200 -4 24 200 4 minecraft:glass_pane
# Licht
setblock 10 200 -3 minecraft:lantern
setblock 10 200 3 minecraft:lantern
setblock 22 200 -3 minecraft:lantern
setblock 22 200 3 minecraft:lantern
# --- Podest 1: DER Lucky Block (Gold-Block) ---
setblock 12 200 0 minecraft:quartz_pillar
setblock 12 201 0 minecraft:verdant_froglight
particle minecraft:end_rod 12 202 0 0.2 0.3 0.2 0.02 20 force @a
# --- Podest 2+3: weitere Lucky Blocks als Blickfang ---
setblock 16 200 -2 minecraft:quartz_pillar
setblock 16 201 -2 minecraft:verdant_froglight
setblock 16 200 2 minecraft:quartz_pillar
setblock 16 201 2 minecraft:verdant_froglight
# --- Rezept-Vitrine: Truhe zeigt die Zutaten (1 Diamant + 3 Glowstone = 1 Lucky Block) ---
setblock 20 200 0 minecraft:quartz_pillar
setblock 20 201 0 minecraft:chest[facing=west]{Items:[{Slot:0b,id:"minecraft:diamond",count:1},{Slot:1b,id:"minecraft:glowstone",count:3},{Slot:8b,id:"minecraft:verdant_froglight",count:1}]}
# Glanz-Effekt ueber der Vitrine
particle minecraft:happy_villager 20 202 0 0.3 0.3 0.3 0.05 30 force @a
# --- HANF-ECKE (Westseite der Terrasse) ---
setblock 9 200 -2 minecraft:water
fill 10 200 -3 12 200 -1 minecraft:farmland[moisture=7]
setblock 10 201 -3 minecraft:wheat[age=2]
setblock 11 201 -2 minecraft:wheat[age=4]
setblock 12 201 -1 minecraft:wheat[age=7]
setblock 10 200 2 minecraft:hay_block
setblock 10 201 2 minecraft:hay_block
# Vitrine: Zutaten fuer Joint & Co.
setblock 12 200 2 minecraft:quartz_pillar
setblock 12 201 2 minecraft:chest[facing=west]{Items:[{Slot:0b,id:"minecraft:wheat_seeds",count:8},{Slot:1b,id:"minecraft:wheat",count:3},{Slot:2b,id:"minecraft:paper",count:1},{Slot:3b,id:"minecraft:glowstone_dust",count:1},{Slot:8b,id:"minecraft:dried_kelp",count:1}]}
particle minecraft:happy_villager 11 202 -2 0.6 0.3 0.6 0.05 30 force @a
# --- LUCKY-STUFEN-AUSSTELLUNG (Suedseite, 5 Stufen nebeneinander) ---
fill 14 200 3 22 200 3 minecraft:quartz_pillar
setblock 14 201 3 minecraft:ochre_froglight
setblock 16 201 3 minecraft:verdant_froglight
setblock 18 201 3 minecraft:pearlescent_froglight
setblock 20 201 3 minecraft:budding_amethyst
setblock 22 201 3 minecraft:sculk_catalyst
particle minecraft:end_rod 18 202 3 4 0.4 0.3 0.02 40 force @a
# --- SLOTAUTOMAT ---
setblock 24 200 0 minecraft:quartz_pillar
setblock 24 201 0 minecraft:jukebox
setblock 24 202 0 minecraft:redstone_lamp
particle minecraft:end_rod 24 202 0 0.3 0.5 0.3 0.02 20 force @a
