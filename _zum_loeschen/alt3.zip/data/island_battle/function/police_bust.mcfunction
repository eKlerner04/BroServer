# ERWISCHT: Mahnung + Strafe
execute if entity @s[tag=ib_wanted] run return 0
tag @s add ib_wanted
scoreboard players set @s police_fine 5
scoreboard players set @s police_t 6000
summon minecraft:vindicator ~3 ~ ~3 {PersistenceRequired:1b,CustomName:"Polizist",Tags:["ib_cop"]}
title @s title {"text":"ERWISCHT!","color":"blue"}
title @s subtitle {"text":"Illegale Substanzen gefunden!","color":"red"}
tellraw @s {"text":"[POLIZEI] MAHNUNG: Zahle 5 Bro-Dollars Strafe mit /trigger zahlen - du hast 5 Minuten!","color":"red"}
tellraw @s {"text":"[POLIZEI] Sonst wird es teurer und wir kommen mit Verstaerkung...","color":"red"}
playsound minecraft:entity.vindicator.ambient master @a ~ ~ ~ 1 0.8
