# Abgabe-Pruefung: poppy
execute if items entity @s container.* minecraft:poppy run function island_battle:quest_win_1
execute unless items entity @s container.* minecraft:poppy run tellraw @s {"text":"[TAGESAUFGABE] Diesmal nicht geschafft - morgen gibt es eine neue. Kein Stress!","color":"gray"}
