# Abgabe-Pruefung: oak_log
execute if items entity @s container.* minecraft:oak_log run function island_battle:quest_win_2
execute unless items entity @s container.* minecraft:oak_log run tellraw @s {"text":"[TAGESAUFGABE] Diesmal nicht geschafft - morgen gibt es eine neue. Kein Stress!","color":"gray"}
