# Abgabe-Pruefung: bread
execute if items entity @s container.* minecraft:bread run function island_battle:quest_win_3
execute unless items entity @s container.* minecraft:bread run tellraw @s {"text":"[TAGESAUFGABE] Diesmal nicht geschafft - morgen gibt es eine neue. Kein Stress!","color":"gray"}
