# Abgabe-Pruefung: torch
execute if items entity @s container.* minecraft:torch run function island_battle:quest_win_4
execute unless items entity @s container.* minecraft:torch run tellraw @s {"text":"[TAGESAUFGABE] Diesmal nicht geschafft - morgen gibt es eine neue. Kein Stress!","color":"gray"}
