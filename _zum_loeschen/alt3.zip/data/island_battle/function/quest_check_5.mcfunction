# Abgabe-Pruefung: white_wool
execute if items entity @s container.* minecraft:white_wool run function island_battle:quest_win_5
execute unless items entity @s container.* minecraft:white_wool run tellraw @s {"text":"[TAGESAUFGABE] Diesmal nicht geschafft - morgen gibt es eine neue. Kein Stress!","color":"gray"}
