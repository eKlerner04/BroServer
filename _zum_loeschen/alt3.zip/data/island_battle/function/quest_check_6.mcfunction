# Abgabe-Pruefung: stone_bricks
execute if items entity @s container.* minecraft:stone_bricks run function island_battle:quest_win_6
execute unless items entity @s container.* minecraft:stone_bricks run tellraw @s {"text":"[TAGESAUFGABE] Diesmal nicht geschafft - morgen gibt es eine neue. Kein Stress!","color":"gray"}
