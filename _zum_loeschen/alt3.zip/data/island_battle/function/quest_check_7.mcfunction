# Abgabe-Pruefung: ladder
execute if items entity @s container.* minecraft:ladder run function island_battle:quest_win_7
execute unless items entity @s container.* minecraft:ladder run tellraw @s {"text":"[TAGESAUFGABE] Diesmal nicht geschafft - morgen gibt es eine neue. Kein Stress!","color":"gray"}
