# Abgabe-Pruefung: bone_meal
execute if items entity @s container.* minecraft:bone_meal run function island_battle:quest_win_8
execute unless items entity @s container.* minecraft:bone_meal run tellraw @s {"text":"[TAGESAUFGABE] Diesmal nicht geschafft - morgen gibt es eine neue. Kein Stress!","color":"gray"}
