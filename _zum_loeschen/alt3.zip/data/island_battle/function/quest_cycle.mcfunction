# Tageswechsel: alte Aufgabe auswerten, neue verteilen
tellraw @a {"text":"[TAGESAUFGABE] Der Tag ist um - Auswertung!","color":"gold"}
function island_battle:quest_eval
function island_battle:quest_assign
scoreboard players set #qtimer quest_t 0
