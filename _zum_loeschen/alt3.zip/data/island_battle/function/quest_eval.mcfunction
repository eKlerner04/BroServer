execute if score #qid quest_t matches 1 as @a at @s run function island_battle:quest_check_1
execute if score #qid quest_t matches 2 as @a at @s run function island_battle:quest_check_2
execute if score #qid quest_t matches 3 as @a at @s run function island_battle:quest_check_3
execute if score #qid quest_t matches 4 as @a at @s run function island_battle:quest_check_4
execute if score #qid quest_t matches 5 as @a at @s run function island_battle:quest_check_5
execute if score #qid quest_t matches 6 as @a at @s run function island_battle:quest_check_6
execute if score #qid quest_t matches 7 as @a at @s run function island_battle:quest_check_7
execute if score #qid quest_t matches 8 as @a at @s run function island_battle:quest_check_8
