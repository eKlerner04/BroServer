clear @s minecraft:bread 1
give @s {id:"minecraft:dried_kelp",count:1,components:{"minecraft:custom_name":"Mega-Joint","minecraft:lore":["Belohnungs-Ware. Absolut heftig."],"minecraft:item_model":"island_battle:premium_joint","minecraft:enchantment_glint_override":1b,"minecraft:food":{nutrition:6,saturation:0.5f,can_always_eat:1b},"minecraft:consumable":{consume_seconds:1.6f,animation:"eat",sound:"minecraft:entity.generic.eat",has_consume_particles:1b,on_consume_effects:[{type:"minecraft:apply_effects",effects:[{id:"minecraft:luck",duration:6000,amplifier:1},{id:"minecraft:speed",duration:2400,amplifier:1},{id:"minecraft:jump_boost",duration:2400,amplifier:1},{id:"minecraft:absorption",duration:2400,amplifier:1},{id:"minecraft:regeneration",duration:600,amplifier:1},{id:"minecraft:glowing",duration:600,amplifier:0}],probability:1.0f}]}}}
give @s minecraft:sponge[custom_name="Ultra-Lucky-Block"] 1
title @s title {"text":"AUFGABE GESCHAFFT!","color":"gold"}
title @s subtitle {"text":"Mega-Joint + Ultra-Lucky-Block!","color":"yellow"}
tellraw @s {"text":"[TAGESAUFGABE] Abgegeben! Der Ultra-Lucky-Block (Schwamm) hat NUR gute Belohnungen.","color":"gold"}
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1
