# === EINMALIGER AUFBAU (Admin) ===
say [BroServer] Baue die Bau-Wettbewerb-Welt auf ...
# Bau-freundliche Regeln (26.x snake_case Gamerules)
gamerule advance_time false
time set 1000
gamerule advance_weather false
weather clear
gamerule keep_inventory true
gamerule immediate_respawn true
gamerule mob_griefing false
gamerule fire_spread_radius_around_player 0
gamerule spawn_monsters false
gamerule show_advancement_messages false
difficulty easy
# Weltgrenze weit weg (keine Border-Schaden)
worldborder center 0 0
worldborder set 4000
# Bauten
function island_battle:build_lobby
function island_battle:build_showcase
function island_battle:build_islands
# Spawn in die Lobby
setworldspawn 0 201 0
spawnpoint @a 0 201 0
say [BroServer] Fertig! Alle Spieler in die Lobby holen, dann: /function island_battle:start
