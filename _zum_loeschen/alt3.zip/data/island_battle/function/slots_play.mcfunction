# Slotautomat: 3 Bro-Dollars Einsatz
execute store result score #cash police_timer run clear @s minecraft:prismarine_shard 0
execute if score #cash police_timer matches ..2 run tellraw @s {"text":"[SLOTS] Du brauchst 3 Bro-Dollars Einsatz!","color":"red"}
execute if score #cash police_timer matches 3.. run function island_battle:slots_roll
