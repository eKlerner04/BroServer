# Entfernt die Datapack-Objekte (vor dem Loeschen des Datapacks)
scoreboard objectives remove ib_admin
say [BroServer] Datapack-Objekte entfernt. Du kannst das Datapack jetzt loeschen.
scoreboard objectives remove lucky_mine
scoreboard objectives remove luck_rng
scoreboard objectives remove lucky_mine_iron
scoreboard objectives remove lucky_mine_lapis
scoreboard objectives remove lucky_mine_dia
scoreboard objectives remove lucky_mine_neth
scoreboard objectives remove trader_timer
scoreboard objectives remove home
scoreboard objectives remove sethome
scoreboard objectives remove home_x
scoreboard objectives remove home_y
scoreboard objectives remove home_z
scoreboard objectives remove police_timer
scoreboard objectives remove police_fine
scoreboard objectives remove police_t
scoreboard objectives remove zahlen
scoreboard objectives remove chem_t
scoreboard objectives remove quest_t
scoreboard objectives remove slots
scoreboard objectives remove lucky_mine_ultra
