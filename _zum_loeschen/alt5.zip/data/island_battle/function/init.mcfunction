# Laeuft bei Serverstart und /reload
scoreboard objectives add ib_admin dummy
# Lucky Blocks: zaehlt abgebaute Bloecke pro Stufe und Spieler
scoreboard objectives add lucky_mine minecraft.mined:minecraft.verdant_froglight
scoreboard objectives add lucky_mine_iron minecraft.mined:minecraft.ochre_froglight
scoreboard objectives add lucky_mine_lapis minecraft.mined:minecraft.pearlescent_froglight
scoreboard objectives add lucky_mine_dia minecraft.mined:minecraft.budding_amethyst
scoreboard objectives add lucky_mine_neth minecraft.mined:minecraft.sculk_catalyst
# Zufallswert fuer die Lucky-Block-Belohnung
scoreboard objectives add luck_rng dummy
# Dealer-Timer
scoreboard objectives add trader_timer dummy
# /home-System
scoreboard objectives add home trigger
scoreboard objectives add sethome trigger
scoreboard objectives add home_x dummy
scoreboard objectives add home_y dummy
scoreboard objectives add home_z dummy
# Polizei-System
scoreboard objectives add police_timer dummy
scoreboard objectives add police_fine dummy
scoreboard objectives add police_t dummy
scoreboard objectives add zahlen trigger
# Chemiker / Tagesaufgaben / Slots / Ultra-Lucky
scoreboard objectives add chem_t dummy
scoreboard objectives add quest_t dummy
scoreboard objectives add slots trigger
scoreboard objectives add lucky_mine_ultra minecraft.mined:minecraft.sponge
scoreboard objectives add slots_state dummy
scoreboard objectives add slots_res dummy
scoreboard players set #btn slots_state 0
scoreboard objectives add pol_g dummy
scoreboard objectives add pol_j dummy
scoreboard objectives add pol_h dummy
scoreboard objectives add abgeben trigger
scoreboard objectives add kunde_t dummy
