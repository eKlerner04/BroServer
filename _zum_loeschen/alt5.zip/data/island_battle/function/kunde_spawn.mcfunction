scoreboard players set #ktimer kunde_t 0
execute store result score #kart kunde_t run random value 1..6
execute if score #kart kunde_t matches 1 positioned 0 200 15 run function island_battle:kunde_1
execute if score #kart kunde_t matches 2 positioned 0 200 15 run function island_battle:kunde_2
execute if score #kart kunde_t matches 3 positioned 0 200 15 run function island_battle:kunde_3
execute if score #kart kunde_t matches 4 positioned 0 200 15 run function island_battle:kunde_4
execute if score #kart kunde_t matches 5 positioned 0 200 15 run function island_battle:kunde_5
execute if score #kart kunde_t matches 6 positioned 0 200 15 run function island_battle:kunde_6
