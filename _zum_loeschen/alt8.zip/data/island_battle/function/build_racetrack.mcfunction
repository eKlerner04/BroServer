# === BRO-BAHN: Eis-Rennstrecke um den Spawn (Boote = Autos!) ===
fill -31 199 -31 31 199 -28 minecraft:blue_ice
fill -31 199 28 31 199 31 minecraft:blue_ice
fill -31 199 -27 -28 199 27 minecraft:blue_ice
fill 28 199 -27 31 199 27 minecraft:blue_ice
# Leitplanken innen/aussen (Stufen als Lippe)
fill -32 200 -32 32 200 -32 minecraft:quartz_slab
fill -32 200 32 32 200 32 minecraft:quartz_slab
fill -32 200 -31 -32 200 31 minecraft:quartz_slab
fill 32 200 -31 32 200 31 minecraft:quartz_slab
fill -27 200 -27 27 200 -27 minecraft:quartz_slab
fill -27 200 27 27 200 27 minecraft:quartz_slab
fill -27 200 -26 -27 200 26 minecraft:quartz_slab
fill 27 200 -26 27 200 26 minecraft:quartz_slab
# Bruecke von der Vorfuehr-Terrasse zur Bahn
fill 24 199 -1 28 199 1 minecraft:smooth_quartz
# Licht an den Ecken
setblock -30 200 -30 minecraft:glowstone
setblock 30 200 -30 minecraft:glowstone
setblock -30 200 30 minecraft:glowstone
setblock 30 200 30 minecraft:glowstone
# Start-Boote an der Bahn
setblock 29 200 -2 minecraft:air
summon minecraft:oak_boat 29 200 0 {CustomName:"Speedboot"}
summon minecraft:oak_boat 29 200 2 {CustomName:"Speedboot"}
# BRO-MOBILE (Kamele = Autos, 2-Sitzer!)
summon minecraft:camel 29 201 -4 {PersistenceRequired:1b,CustomName:"Bro-Mobil",Tame:1b}
summon minecraft:camel 26 201 5 {PersistenceRequired:1b,CustomName:"Bro-Mobil",Tame:1b}
# === FRIEDENS-ECKE: Tipi mit Lagerfeuer ===
fill -14 200 8 -10 200 12 minecraft:white_wool
fill -13 201 9 -11 201 11 minecraft:white_wool
setblock -12 202 10 minecraft:white_wool
setblock -12 201 10 minecraft:air
setblock -12 200 10 minecraft:campfire
setblock -12 200 8 minecraft:air
fill -13 200 9 -11 200 11 minecraft:air
setblock -12 200 10 minecraft:campfire
