# Tier-Ansturm am Sammelpunkt
summon minecraft:cat ~1 ~ ~1 {PersistenceRequired:1b,Tags:["ib_tier"]}
summon minecraft:parrot ~-1 ~1 ~1 {PersistenceRequired:1b,Tags:["ib_tier"]}
summon minecraft:frog ~1 ~ ~-1 {PersistenceRequired:1b,Tags:["ib_tier"]}
summon minecraft:rabbit ~-1 ~ ~-1 {PersistenceRequired:1b,Tags:["ib_tier"]}
summon minecraft:fox ~2 ~ ~ {PersistenceRequired:1b,Tags:["ib_tier"]}
tellraw @a {"text":"[SAMMELPUNKT] Tierischer Besuch! Ein paar neugierige Tiere schauen am Treffpunkt vorbei.","color":"green"}
playsound minecraft:entity.cat.ambient master @a
