# Tageswechsel: alte Aufgabe auswerten, neue verteilen
tellraw @a {"text":"[TAGESAUFGABE] Der Tag ist um - Auswertung!","color":"gold"}
function island_battle:quest_eval
tag @a remove ib_quest_done
function island_battle:quest_assign
scoreboard players set #qtimer quest_t 0
kill @e[type=minecraft:villager,tag=ib_kunde]
kill @e[tag=ib_tier]
kill @e[type=minecraft:item_display]
tellraw @a {"text":"[SAMMELPUNKT] Die Kundschaft macht Feierabend - morgen kommen neue!","color":"gray"}
