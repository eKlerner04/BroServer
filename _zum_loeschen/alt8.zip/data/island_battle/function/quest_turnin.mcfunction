execute if entity @s[tag=ib_quest_done] run tellraw @s {"text":"[TAGESAUFGABE] Du hast heute schon abgegeben - morgen gibt es eine neue!","color":"gray"}
execute if entity @s[tag=ib_quest_done] run return 0
execute if score #qid quest_t matches 1 run function island_battle:quest_check_1
execute if score #qid quest_t matches 2 run function island_battle:quest_check_2
execute if score #qid quest_t matches 3 run function island_battle:quest_check_3
execute if score #qid quest_t matches 4 run function island_battle:quest_check_4
execute if score #qid quest_t matches 5 run function island_battle:quest_check_5
execute if score #qid quest_t matches 6 run function island_battle:quest_check_6
execute if score #qid quest_t matches 7 run function island_battle:quest_check_7
execute if score #qid quest_t matches 8 run function island_battle:quest_check_8
