# Laeuft jeden Tick
# --- Lucky Blocks: hat jemand einen abgebaut? (pro Stufe) ---
execute as @a[scores={lucky_mine=1..}] at @s run function island_battle:lucky_open
execute as @a[scores={lucky_mine_iron=1..}] at @s run function island_battle:lucky_open_iron
execute as @a[scores={lucky_mine_lapis=1..}] at @s run function island_battle:lucky_open_lapis
execute as @a[scores={lucky_mine_dia=1..}] at @s run function island_battle:lucky_open_dia
execute as @a[scores={lucky_mine_neth=1..}] at @s run function island_battle:lucky_open_neth
# Zaehler zuruecksetzen
scoreboard players set @a lucky_mine 0
scoreboard players set @a lucky_mine_iron 0
scoreboard players set @a lucky_mine_lapis 0
scoreboard players set @a lucky_mine_dia 0
scoreboard players set @a lucky_mine_neth 0
# --- Dealer-Besuchs-Timer ---
function island_battle:trader_tick
# --- /home-System (Spieler nutzen /trigger home und /trigger sethome) ---
scoreboard players enable @a home
scoreboard players enable @a sethome
execute as @a[scores={sethome=1..}] at @s run function island_battle:sethome_here
execute as @a[scores={home=1..}] at @s run function island_battle:home_go
scoreboard players set @a home 0
scoreboard players set @a sethome 0
# --- Polizei-System ---
function island_battle:police_tick
scoreboard players enable @a zahlen
execute as @a[scores={zahlen=1..}] at @s run function island_battle:police_pay
scoreboard players set @a zahlen 0
# --- Chemiker ---
function island_battle:chem_tick
# --- Tagesaufgaben (alle 24000 Ticks = 1 MC-Tag) ---
scoreboard players add #qtimer quest_t 1
execute if score #qtimer quest_t matches 24000.. run function island_battle:quest_cycle
# --- Ultra-Lucky ---
execute as @a[scores={lucky_mine_ultra=1..}] at @s run function island_battle:lucky_open_ultra
scoreboard players set @a lucky_mine_ultra 0
# --- Slotautomat ---
scoreboard players enable @a slots
execute as @a[scores={slots=1..}] at @s run function island_battle:slots_play
scoreboard players set @a slots 0
function island_battle:slots_button
# --- Tagesaufgabe manuell abgeben ---
scoreboard players enable @a abgeben
execute as @a[scores={abgeben=1..}] at @s run function island_battle:quest_turnin
scoreboard players set @a abgeben 0
# --- Laufkundschaft am Sammelpunkt ---
function island_battle:kunde_tick
scoreboard players enable @a sammelpunkt
execute as @a[scores={sammelpunkt=1..}] at @s run function island_battle:sp_set
scoreboard players set @a sammelpunkt 0
